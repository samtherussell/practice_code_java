<?php
require 'connect.inc.php';


$id =  $_GET['id'];
$dist = $_GET['distance'];

				$query = "UPDATE CountdownPlayers SET Player_DIST=$dist WHERE Player_ID='$id'";
				
				mysql_query($query);
			

?>